# machine-learning
ML TU Wien

Using Jupyter Notebook for the assignment:

1) Download and install [Anaconda](https://www.anaconda.com/distribution/#download-section) 
2) Launch Jupyter Notebook after installation (see screenshot)
![Launch Jupyter](https://i.imgur.com/EXC04Xa.png "Launch Jupyter")
3) Open up the .ipynb files for each assignment and run them
